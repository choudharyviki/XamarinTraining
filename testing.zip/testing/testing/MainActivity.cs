﻿using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.Design.Widget;
using Android.Support.V7.App;
using Android.Util;
using Android.Views;
using Android.Views.InputMethods;
using Android.Widget;
using Java.Util;
using testing.Activity;

namespace testing
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme.NoActionBar", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        EditText userNameEditText;
        EditText passwordEditText;
        Button loginButton;
        View loginview;
        TextView userNameError;
        TextView passwordError;
        TextView bothError;
        Button changeLanguageBtn;
        string languagecode;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_main);

            Android.Support.V7.Widget.Toolbar toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar);
            SetSupportActionBar(toolbar);

            //FloatingActionButton fab = FindViewById<FloatingActionButton>(Resource.Id.fab);
            //fab.Click += FabOnClick;
            userNameEditText = FindViewById<EditText>(Resource.Id.userName);
            passwordEditText = FindViewById<EditText>(Resource.Id.password);
            loginButton = FindViewById<Button>(Resource.Id.login);
            userNameError = FindViewById<TextView>(Resource.Id.usererror);
            passwordError = FindViewById<TextView>(Resource.Id.passworderror);
            bothError = FindViewById<TextView>(Resource.Id.botherror);
             loginButton.Click += LoginButton_Click;
        }

        public override bool OnTouchEvent(MotionEvent e)
        {
            InputMethodManager imm = (InputMethodManager)GetSystemService(Context.InputMethodService);
            imm.HideSoftInputFromWindow(userNameEditText.WindowToken, 0);
            return base.OnTouchEvent(e);

        }
        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(userNameEditText.Text) && string.IsNullOrEmpty(passwordEditText.Text))
            {
                userNameError.Visibility = ViewStates.Visible;
                passwordError.Visibility = ViewStates.Visible;
                return;
            }
            if (userNameEditText.Text == "Admin" && string.IsNullOrEmpty(passwordEditText.Text))
            {
                bothError.Visibility = ViewStates.Gone;
                userNameError.Visibility = ViewStates.Gone;
                passwordError.Visibility = ViewStates.Visible;
                return;

            }
            if (string.IsNullOrEmpty( userNameEditText.Text) && passwordEditText.Text=="Admin")
            {
                bothError.Visibility = ViewStates.Gone;
                userNameError.Visibility = ViewStates.Visible;
                passwordError.Visibility = ViewStates.Gone;
                return;

            }
            if (userNameEditText.Text == "Admin" && passwordEditText.Text == "Admin")
            {
                userNameError.Visibility = ViewStates.Gone;
                passwordError.Visibility = ViewStates.Gone;
                bothError.Visibility = ViewStates.Gone;

                var intent = new Intent();
                intent.SetClass(Application.Context, typeof(LoginSuccess));
                StartActivity(intent);
            }
            else
            {
                bothError.Visibility = ViewStates.Visible;
                userNameError.Visibility = ViewStates.Gone;
                passwordError.Visibility = ViewStates.Gone;

            }
           
        }

        public override bool OnCreateOptionsMenu(IMenu menu)
        {
            MenuInflater.Inflate(Resource.Menu.menu_main, menu);
            return true;
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            int id = item.ItemId;
            if (id == Resource.Id.action_settings)
            {
                return true;
            }

            return base.OnOptionsItemSelected(item);
        }
        protected override void OnResume()
        {
            base.OnResume();
            userNameEditText.Text = string.Empty;
            passwordEditText.Text = string.Empty;
        }
        protected override void OnPause()
        {
            base.OnPause();
        }
        private void FabOnClick(object sender, EventArgs eventArgs)
        {
            View view = (View) sender;
            Snackbar.Make(view, "Replace with your own action", Snackbar.LengthLong)
                .SetAction("Action", (Android.Views.View.IOnClickListener)null).Show();
        }
	}
}

