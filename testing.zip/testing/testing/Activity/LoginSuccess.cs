﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Content.Res;
using Android.OS;
using Android.Preferences;
using Android.Runtime;
using Android.Support.V7.App;
using Android.Util;
using Android.Views;
using Android.Widget;
using Java.Util;

namespace testing.Activity
{
    [Activity(Label = "")]
    public class LoginSuccess : AppCompatActivity
    {
        Button englishBtn;
        Button hindiBtn;
        Button frenchBtn;
        Button japanBtn;
        Button backBtn;
        private Locale mCurrentLocale;
        String lang = "de";
        string languagecode;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
           
            SetContentView(Resource.Layout.login_success);
            englishBtn = FindViewById<Button>(Resource.Id.english);
            hindiBtn = FindViewById<Button>(Resource.Id.hindi);
            frenchBtn = FindViewById<Button>(Resource.Id.french);
            japanBtn = FindViewById<Button>(Resource.Id.japan);
            backBtn = FindViewById<Button>(Resource.Id.back);
            englishBtn.Click += EnglishBtn_Click;
            frenchBtn.Click += FrenchBtn_Click;
            hindiBtn.Click += HindiBtn_Click;
            japanBtn.Click += JapanBtn_Click;
            backBtn.Click += BackBtn_Click;
        }

       
       
        private void BackBtn_Click(object sender, EventArgs e)
        {
            Finish();
        }
        //Call for japanees language
        private void JapanBtn_Click(object sender, EventArgs e)
        {
            languagecode = "je";
            Android.Content.Res.Resources res = this.Resources;
            DisplayMetrics dm = res.DisplayMetrics;
            Android.Content.Res.Configuration conf = res.Configuration;
                conf.SetLocale(new Locale(languagecode));
            res.UpdateConfiguration(conf, dm);
            this.Recreate();
        }
        //call for hindi language
        private void HindiBtn_Click(object sender, EventArgs e)
        {
            languagecode = "hi";
            Android.Content.Res.Resources res = this.Resources;
            DisplayMetrics dm = res.DisplayMetrics;
            Android.Content.Res.Configuration conf = res.Configuration;
                conf.SetLocale(new Locale(languagecode));
            res.UpdateConfiguration(conf, dm);
            this.Recreate();
        }
        //Call for french language
        private void FrenchBtn_Click(object sender, EventArgs e)
        {
            languagecode = "fe";
            Android.Content.Res.Resources res = this.Resources;
            DisplayMetrics dm = res.DisplayMetrics;
            Android.Content.Res.Configuration conf = res.Configuration;
                conf.SetLocale(new Locale(languagecode));
            res.UpdateConfiguration(conf, dm);
            this.Recreate();
        }
        //Call for english language
        private void EnglishBtn_Click(object sender, EventArgs e)
        {
            languagecode = "en";
            Android.Content.Res.Resources res = this.Resources;
            DisplayMetrics dm = res.DisplayMetrics;
            Android.Content.Res.Configuration conf = res.Configuration;
                conf.SetLocale(new Locale(languagecode));
            res.UpdateConfiguration(conf, dm);
            this.Recreate();
        }
    }
}